


int anyEvenBit();
int test_anyEvenBit();
int bitNor(int, int);
int test_bitNor(int, int);
int bitParity(int);
int test_bitParity(int);
int conditional(int, int, int);
int test_conditional(int, int, int);
int isLess(int, int);
int test_isLess(int, int);
int isTmax(int);
int test_isTmax(int);
int logicalNeg(int);
int test_logicalNeg(int);
int reverseBytes(int);
int test_reverseBytes(int);
int sign(int);
int test_sign(int);
int subOK(int, int);
int test_subOK(int, int);
int trueThreeFourths(int);
int test_trueThreeFourths(int);
int tc2sm(int);
int test_tc2sm(int);
